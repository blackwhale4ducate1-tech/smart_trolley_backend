// const getEstimateInvoiceDetailsModel = require("./models/estimateInvoiceDetailsModel");

// const estimate_invoice_details = getEstimateInvoiceDetailsModel("branch2");
// // const users = require("./models/usersModel");

// // Sync only the Admin model
// estimate_invoice_details
//   .sync({ force: false }) // Set to true to drop and recreate the table on every sync
//   .then(() => {
//     console.log("Table has been synchronized with timestamps.");
//   })
//   .catch((err) => {
//     console.error("Error synchronizing the admin table:", err);
//   });
